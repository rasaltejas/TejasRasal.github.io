
import React from 'react';

interface ProjectCardProps {
  title: string;
  description: string;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ title, description }) => {
  return (
    <div className="flex-1 min-w-[280px]">
      <h3 className="font-semibold text-gray-900">{title}</h3>
      <p className="mt-1 text-gray-600 text-sm leading-relaxed">{description}</p>
    </div>
  );
};

export default ProjectCard;
